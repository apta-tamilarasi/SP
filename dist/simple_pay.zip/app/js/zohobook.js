

const journalCreate = async (details) => {
    let isJournal = false
    let textarea = document.getElementsByTagName("textarea")
    console.log(textarea[0].value);

    console.log(journalDate);

    console.log(details);
    console.log(fieldmappingData);

    let custom = {
        url: `${orgDetails.dc}/cm__com_kz7zl3_journal_record?organization_id=${orgDetails.orgId}`,
        method: "GET",
        connection_link_name: "zohobook",
    };
    ZFAPPS.request(custom)
        .then(async function (value) {
            let record = JSON.parse(value.data.body)
            if (record.module_records.length !== 0) {
                isJournal = record.module_records.find((re) => {
                    return `Simple Pay - ${paymentRunId}` === re.cf__com_kz7zl3_reference_id
                })
            }
        })
        .catch(function (err) {
            console.error("err", err);
        })
    if (!isJournal) {
        const journalData = {
            "journal_date": `${journalDate}`,
            // "entry_number":`sample pay -${journalNumber}`,
            "reference_number": `Simple Pay - ${paymentRunId}`,
            "notes": `Simple Pay ${journalDate} - ${textarea[0].value}`,
            "line_items": [
                {
                    "account_id": fieldmappingData[0].cf__com_kz7zl3_debit_other,
                    "debit_or_credit": "debit",
                    "amount": 0,
                    "description": "Other Expense"
                },
                {
                    "account_id": fieldmappingData[0].cf__com_kz7zl3_credit_other,
                    "debit_or_credit": "credit",
                    "amount": 0,
                    "description": "Other Liability"
                }
            ]
        }

        details.credit.map((c) => {
            let account = ""
            let otherExpense = false
            if (c.line_item === "medical_aid_liability") {
                account = fieldmappingData[0].cf__com_kz7zl3_credit_medical
            }
            else if (c.line_item === "nett_pay") {
                account = fieldmappingData[0].cf__com_kz7zl3_credit_nett_pay
            }
            else if (c.line_item === "sdl_employer") {
                account = fieldmappingData[0].cf__com_kz7zl3_credit_sdl_employer
            }
            else if (c.line_item === "uif_total") {
                account = fieldmappingData[0].cf__com_kz7zl3_debit_uif_total
            }
            else if (c.line_item === "pension_fund_total") {
                account = fieldmappingData[0].cf__com_kz7zl3_credit_pension
            }
            else if (c.line_item === "tax") {
                account = fieldmappingData[0].cf__com_kz7zl3_credit_tax
            }
            else {
                account = fieldmappingData[0].cf__com_kz7zl3_debit_other
                otherExpense = true
            }
            let total = Object.values(c.amount).reduce((acc, val) => acc + val, 0);
            if (otherExpense) {
                journalData.line_items[1].amount = journalData.line_items[0].amount + total
            }
            else {
                let obj = {
                    "account_id": account,
                    "debit_or_credit": "credit",
                    "amount": total,
                    "description": c.label + " Liability"
                }
                journalData.line_items.push(obj)
            }

        })
        details.debit.map((d) => {
            let account = ""
            let otherExpense = false
            if (d.line_item === "basic_salary") {
                account = fieldmappingData[0].cf__com_kz7zl3_debit_basic_salary
            }
            else if (d.line_item === "medical_aid_employer") {
                account = fieldmappingData[0].cf__com_kz7zl3_debit_medical
            }
            else if (d.line_item === "sdl_employer") {
                account = fieldmappingData[0].cf__com_kz7zl3_field_mapping
            }
            else if (d.line_item === "uif_employer") {
                account = fieldmappingData[0].cf__com_kz7zl3_debit_uif_employer
            }
            else if (d.line_item === "pension_fund_employer") {
                account = fieldmappingData[0].cf__com_kz7zl3_debit_pension
            }
            else {
                account = fieldmappingData[0].cf__com_kz7zl3_debit_other
                otherExpense = true
            }
            let total = Object.values(d.amount).reduce((acc, val) => acc + val, 0);
            console.log(total, otherExpense);

            if (otherExpense) {
                journalData.line_items[0].amount = journalData.line_items[0].amount + total
            }
            else {
                let obj = {
                    "account_id": account,
                    "debit_or_credit": "debit",
                    "amount": total,
                    "description": d.label + " Expense"
                }
                journalData.line_items.push(obj)
            }

        })


        journalData.line_items = journalData.line_items.filter((line) => {
            return line.amount !== 0

        })
        let journal = {
            url: `${orgDetails.dc}/journals?organization_id=${orgDetails.orgId}`,
            method: "POST",
            body: {
                mode: "raw",
                raw: journalData,
            },
            connection_link_name: "zohobook",
        };
        ZFAPPS.request(journal)
            .then( async function (value) {
                let responseJSON = JSON.parse(value.data.body);
                console.log(responseJSON);
                
                if (responseJSON.code == 0) {
                    ShowNotification("success", "Journal created successfully into zohobook")
                    createJournalBtn.style.display = "none"
                    createJournalBtn.disabled = false
                    paymentRunDiv.style.visibility = "hidden"
                    textareaDiv.style.visibility = "hidden"
                    textarea[0].value = ""
                   await journalCustomCreate(responseJSON)
                    simplepayClientGet()
                }
                else {
                    createJournalBtn.disabled = false
                    ShowNotification("error", `${responseJSON.message}`)
                }

            })
            .catch(function (err) {
                console.error("err", err);
            });
    }
    else {

    }


}

const journalCustomCreate = async(journalData) => {
    let data={
        "cf__com_kz7zl3_reference_id":journalData.journal.reference_number,
        "cf__com_kz7zl3_id":journalData.journal.journal_id,
        "cf__com_kz7zl3_date":journalData.journal.journal_date,
        "cf__com_kz7zl3_notes":journalData.journal.notes,
        "cf__com_kz7zl3_total":journalData.journal.total,
    }
    let custom = {
      url: `${orgDetails.dc}/cm__com_kz7zl3_journal_record?organization_id=${orgDetails.orgId}`,
      method: "POST",
      body: {
        mode: "raw",
        raw: data,
      },
      connection_link_name: "zohobookscontact",
    };
    ZFAPPS.request(custom)
      .then(function (value) {
        let responseJSON = JSON.parse(value.data.body);
        console.log(responseJSON);
        
      })
      .catch(function (err) {
        console.error("err", err);
      });
  };


